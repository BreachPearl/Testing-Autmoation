package javaBasics;

public class SecondClass {

	public static void main(String[] args)
	{
	
		int a = 20;
		System.out.println("value of a: " + a);
		
		
		FirstClass fc = new FirstClass();
		fc.printValues();
		

	}

}
