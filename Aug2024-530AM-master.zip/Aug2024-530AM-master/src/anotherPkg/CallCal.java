package anotherPkg;

import javaBasics.Calculations;

public class CallCal {

	public static void main(String[] args)
	{
	
		
		Calculations cal1 = new Calculations();
		cal1.sum();
		//cal1.printvalues();

	}

}
