package oopsConcept;

public interface QA3I extends QA1I
{

	public void qa3im();
	
}
