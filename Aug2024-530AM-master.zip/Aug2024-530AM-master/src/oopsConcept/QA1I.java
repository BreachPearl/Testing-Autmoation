package oopsConcept;

public interface QA1I 
{

	public void qa1im();
	
}
