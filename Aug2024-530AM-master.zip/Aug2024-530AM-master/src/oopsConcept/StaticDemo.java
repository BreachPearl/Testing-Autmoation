package oopsConcept;

public class StaticDemo
{
	static int a = 20;
	
	public static void printval()
	{
		
		
		System.out.println(a);
	}
	
	public static void main(String[] args) 
	{
		StaticDemo.printval();
		
	}
	
}
