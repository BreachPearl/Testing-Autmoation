package oopsConcept;

public interface InterfaceDemo 
{

	int a = 20;
	
	
	public void m3();
	public void m4();
	
}
